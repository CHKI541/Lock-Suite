# Instrucciones para Antigravity — pendientes de la tercera revisión de Claude

**Fecha:** 14 de agosto de 2026
**Contexto:** Claude revisó los cambios de la v0.4.9.3 a la v0.6.12 y auditó las correcciones aplicadas por Antigravity. Este archivo lista **únicamente lo que Claude no pudo hacer** desde su entorno (no tiene SDK de Android, ni puede compilar, desplegar ni probar en un equipo real), más las decisiones que requieren criterio del dueño del proyecto.

Claude ya aplicó y dejó escritos en el repo 6 archivos corregidos. Esos **no** hay que rehacerlos — solo compilar, probar y desplegar. Están listados en la sección 0 para que puedas verificarlos.

---

## 0. Lo que Claude ya dejó aplicado (verificar, no rehacer)

| Archivo | Qué se cambió |
|---|---|
| `app/src/main/java/com/ejemplo/locksuite/service/KosherVpnService.kt` | Los UID del sistema (< 10000) ya no se tratan como si fueran de una app. Restaura la lista negra global de WebView y la regla de Mercado Pago por VPN. |
| `app/src/main/java/com/ejemplo/locksuite/util/NetworkForwarder.kt` | Se eliminó un comentario obsoleto que describía una protección ya removida, y se agregó la verificación de dirección de origen de la respuesta DNS (equivalente a `socket.connect()` pero sin tocar el enrutamiento). |
| `admin-backend/database.rules.json` | Se eliminaron las reglas hijas `pinHash`, `pinSalt` y `recoveryCode` que concedían `auth != null` y anulaban la comprobación de `ownerUid` del nodo padre. |
| `app/src/main/java/com/ejemplo/locksuite/mdm/PolicyManager.kt` | Se revirtió la guarda `if (SDK >= P)` sobre `DISALLOW_CONFIG_MOBILE_NETWORKS`. |
| `admin-backend/public/app.js` | `rememberDevice` en comandos de grupo pasó de `true` fijo a `false`. |
| `admin-backend/functions/index.js` | Se agregó `isTrivialPin()` y su comprobación en el comando `CHANGE_PIN`. |

**Verificación esperada:** `./gradlew compileDebugKotlin` debe terminar en BUILD SUCCESSFUL, y `node --check` debe pasar en los dos archivos JS (Claude ya validó la sintaxis JS y el JSON, pero no pudo compilar Kotlin).

---

## 1. Tareas de compilación, despliegue y prueba

### 1.1 Subir el versionCode antes de publicar
`app/build.gradle.kts` está en `versionCode = 74` / `versionName = "0.6.12"`, que es lo que ya está publicado. Si se compila y publica con el mismo número, los equipos que ya tienen la 74 **no** van a tomar la actualización (Android rechaza instalar un versionCode igual o menor). Subir a 75 / 0.6.13 antes del build de release, y actualizar `admin-backend/public/version.json` en la misma operación para que coincida.

### 1.2 Desplegar backend
```bash
cd admin-backend
firebase deploy --only database    # reglas corregidas — NO omitir, es el fix de seguridad
firebase deploy --only functions   # isTrivialPin en CHANGE_PIN
firebase deploy --only hosting     # rememberDevice en comandos de grupo
```

### 1.3 Checklist de prueba en equipo real
Priorizado por riesgo de regresión de los cambios de Claude:

1. **Bloqueo de WebView y de ofertas de Mercado Pago** (es el cambio de mayor impacto). Con una app que tenga el bloqueo de WebView activado, confirmar que ahora sí se bloquean los dominios de la lista negra global. Antes de este cambio no se bloqueaban.
2. **Resolución DNS normal**: navegar varios sitios permitidos y confirmar que no hay lentitud ni fallos nuevos. La verificación de dirección de origen en `NetworkForwarder` es el punto donde una regresión se notaría como "no carga nada".
3. **Bloqueo de un dominio**: entrar a un dominio bloqueado y confirmar que falla al instante, no que se queda esperando.
4. **Sincronización con Firebase**: confirmar que un equipo sigue apareciendo en línea y que puede escribir su estado tras el cambio de reglas. Si algún equipo deja de sincronizar, revisar primero la consola de Firebase por `permission-denied`.
5. **Cambio de PIN desde el panel**: probar que "1234" y "0000" ahora se rechazan con mensaje claro, y que un PIN normal sigue funcionando.
6. **Comandos de grupo**: confirmar que siguen funcionando con el PIN cacheado en la sesión. Si un equipo del grupo nunca tuvo el PIN ingresado en esa sesión, va a fallar con `PIN_REQUIRED` — ese es el comportamiento correcto ahora.
7. **Bloqueo de Wi-Fi en un equipo con Android 7 u 8**, si hay uno disponible: confirmar si `DISALLOW_CONFIG_MOBILE_NETWORKS` se aplica o si el sistema la rechaza. Ahora se vuelve a intentar siempre y se reporta el resultado real, así que si falla se va a ver.

---

## 2. Correcciones de código que Claude no hizo (requieren decisión o contexto que no tiene)

### 2.1 `UPDATE_APP` ya no levanta las restricciones de instalación — decidir e implementar
**Archivo:** `app/src/main/java/com/ejemplo/locksuite/service/LockSuiteFirebaseService.kt`, bloque del comando `UPDATE_APP`.

La reescritura de este comando eliminó dos cosas que antes hacía: ya no escribe la bandera `mdm_install_in_progress`, y ya no llama a `clearUserRestriction` sobre `DISALLOW_INSTALL_APPS` ni `DISALLOW_INSTALL_UNKNOWN_SOURCES`. Consecuencias observadas al leer el código:

- Con el bloqueo de instalaciones activo (el estado normal de estos equipos), Play Store no va a poder completar la actualización. El comando abre la ficha de la app y devuelve éxito igual.
- El bloque de `LockSuiteAccessibilityService` que redirige de vuelta a Play Store está condicionado a `mdm_install_in_progress`, así que ya no se ejecuta nunca para este flujo. La corrección de excluir `com.google.android.gms` y los instaladores quedó sin efecto en el camino que pretendía arreglar.
- El comentario del código dice *"mismo flag de siempre para que la politica de instalacion no la bloquee"*, pero la bandera que escribe (`updating_package`) no es la que controla eso.

**Hay que decidir cuál de las dos:**

- **(a) Si el cambio fue deliberado** (reducir la ventana en que se relajan las restricciones es una decisión defensiva legítima): corregir el comentario para que describa lo que el código hace, y documentar que `UPDATE_APP` no funciona con el bloqueo de instalaciones activo. Idealmente, que el comando devuelva un error explícito en ese caso en vez de éxito, comprobando `isInstallAppsBlocked()` antes de intentar.
- **(b) Si fue un descuido**: restaurar la escritura de `mdm_install_in_progress = true` y el levantamiento temporal de las dos restricciones, manteniendo la alarma de seguridad que las vuelve a imponer. Verificar además que `updating_package` se limpie al terminar, en éxito y en fallo.

En cualquiera de los dos casos: verificar que `updating_package` no quede con un valor viejo, porque si después una autoactualización de LockSuite pone `mdm_install_in_progress = true`, el servicio de accesibilidad va a redirigir al usuario a la ficha de un paquete que no corresponde.

### 2.2 Aislamiento real de escritura por dispositivo en Firebase — cambio de arquitectura
**Archivos:** `admin-backend/database.rules.json`, `admin-backend/functions/index.js`, `app/src/main/java/com/ejemplo/locksuite/util/FirebaseDeviceSync.kt`.

La regla actual de `devices/$device_id` incluye esta condición:

```
newData.child('ownerUid').val() === auth.uid
```

`newData` es el dato que se está escribiendo, así que alcanza con incluir el propio uid como `ownerUid` dentro de la escritura para que la regla dé verdadero. Cualquiera puede apropiarse del nodo de cualquier dispositivo simplemente declarando que es suyo. Mientras esa condición esté, la comprobación de propiedad no protege de nada.

La condición no se puede borrar sin más: sin ella, un celular cuyo uid anónimo cambie (pasa al reinstalar la app o al borrar sus datos) no podría volver a escribir en su propio nodo y desaparecería del panel. El problema de fondo es que **un uid de sesión anónima no es una identidad estable de dispositivo**, así que no sirve como base de una regla de propiedad.

**Dos caminos posibles, elegir uno:**

- **(a) Custom Token por dispositivo (preferido).** Agregar una Cloud Function de aprovisionamiento que reciba el `deviceId` y devuelva un Custom Token de Firebase Auth con un claim `deviceId`. Cambiar `FirebaseDeviceSync.withAuth()` para usar `signInWithCustomToken` en vez de `signInAnonymously`. Después la regla puede exigir `auth.token.deviceId === $device_id`, que sí es infalsificable. Hay que resolver cómo se autentica la primera llamada de aprovisionamiento (por ejemplo, un token de un solo uso generado al preparar el equipo).
- **(b) Escrituras detrás de Cloud Function.** Mover todas las escrituras del dispositivo (`syncToken`, `syncDeviceInfo`, `syncPinCredentials`, etc.) a una Cloud Function que valide y escriba con el Admin SDK, y dejar las reglas de `devices` y `deviceSecrets` en `.write: false` para clientes. Es más simple de razonar pero agrega latencia y costo por cada sincronización.

**Importante durante la migración:** hay equipos en producción sin `ownerUid` o con uno viejo. Cualquiera de los dos caminos necesita un período de convivencia o una migración explícita, o esos equipos van a dejar de sincronizar.

### 2.3 Verificación de integridad del APK descargado por OTA
**Archivo:** `app/src/main/java/com/ejemplo/locksuite/util/SelfUpdater.kt`.

Hoy se descarga el APK desde la URL que indica `version.json` y se instala en silencio con privilegios de Device Owner, sin comparar ningún checksum. Para la autoactualización de LockSuite, Android exige el mismo certificado de firma, lo que da cierta protección gratis. Para la **Tienda administrada** (`downloadAndInstallApk`, que instala paquetes nuevos) esa protección no aplica: es la primera instalación de ese paquete, así que Android acepta cualquier certificado.

**Implementar:** agregar un campo `sha256` al `version.json` y a cada entrada de `storeApps` en la base de datos. Después de descargar y antes de abrir la sesión de `PackageInstaller`, calcular el SHA-256 del archivo temporal y compararlo. Si no coincide: borrar el archivo temporal, **no** abrir la sesión de instalación, restaurar las restricciones y devolver un error claro. La comparación tiene que ser sobre el archivo ya descargado en disco, no sobre el stream.

### 2.4 Firma asimétrica de los perfiles (`.locksuite`)
**Archivos:** `app/src/main/java/com/ejemplo/locksuite/mdm/PolicyManager.kt`, `admin-backend/public/app.js`.

La clave HMAC que firma los perfiles (`LockSuiteMDM_Preset_HMAC_SecretKey_2026`) está en texto plano en `app.js`, que Firebase Hosting sirve públicamente, y además en el repositorio de GitHub, que es público. O sea que cualquiera puede firmar un perfil que la app va a dar por válido. La firma actual no aporta ninguna garantía real de integridad.

**Implementar:** reemplazar el HMAC simétrico por una firma asimétrica (ECDSA P-256 o RSA-2048). La clave privada vive solo en una Cloud Function que firma los perfiles al guardarlos; la clave pública se embebe en la app y solo se usa para verificar. La app nunca debe poder generar una firma válida.

### 2.5 `UPDATE_LOCKSUITE` no pide el PIN del dispositivo
**Archivo:** `admin-backend/functions/index.js`, línea del tipo `if (command !== "UPDATE_LOCKSUITE") await verifyDevicePin(...)`.

Un administrador autorizado puede empujar una actualización a cualquier equipo sin conocer su PIN. Combinado con 2.3 (sin verificación de checksum) y con que el APK se sirve desde un repositorio público, esa es la ruta más corta que existe hoy para meter código nuevo en un celular.

**Decidir:** si la excepción es deliberada (para poder actualizar equipos cuyo PIN se perdió), dejarla pero documentarla explícitamente en el código y registrarla en `commandLog` de forma destacada. Si no lo es, quitar la excepción y exigir el PIN también para este comando.

### 2.6 Restricción de fecha y hora
**Archivo:** `app/src/main/java/com/ejemplo/locksuite/mdm/PolicyManager.kt`.

`DISALLOW_CONFIG_DATE_TIME` no se aplica en ningún lado del proyecto. Claude ya blindó el bloqueo por intentos fallidos de PIN usando un reloj monotónico, así que el ataque de "adelantar la hora para saltear el bloqueo" ya no funciona. Pero aplicar la restricción cerraría la puerta del todo y además protege otras cosas que dependen del reloj.

**Implementar como un interruptor más del panel** (no forzada), siguiendo el mismo patrón que las demás restricciones: función en `PolicyManager`, comandos `BLOCK_DATE_TIME` / `UNBLOCK_DATE_TIME` en `ALLOWED_COMMANDS`, manejador en `LockSuiteFirebaseService`, campo en `syncDeviceInfo` y switch en el panel. Es una decisión de producto porque el usuario final pierde la posibilidad de corregir la hora aunque esté mal.

### 2.7 Cartel en el panel para las limitaciones del bloqueo por app
**Archivo:** `admin-backend/public/app.js` y el HTML del panel.

Cada celular ya reporta los campos `perAppDnsRulesSupported` y `androidSdkInt` (los agregó Claude en una revisión anterior). Todavía no se usan en el panel.

**Implementar:** mostrar una advertencia visible en la ficha del dispositivo cuando los interruptores de "Bloquear WebView por app" o "Bloquear internet por app" estén activos. El texto tiene que ser honesto sobre dos límites distintos:

- En equipos con Android menor a 10, la API que atribuye cada consulta DNS a una app no existe: esas reglas no se aplican nunca.
- En **todas** las versiones, las consultas DNS de las apps que usan el resolutor del sistema las emite `netd` en nombre de la app, así que tampoco se pueden atribuir. El bloqueo por app solo alcanza a las apps que resuelven DNS por su cuenta.

Lo que sí funciona en todos los equipos, y conviene aclararlo en el mismo cartel: las reglas DNS personalizadas, el bloqueo de anuncios, el de GIFs, la lista negra global de WebView y el bloqueo de ofertas de Mercado Pago.

---

## 3. Decisión que no es de código

**El repositorio `CHKI541/Lock-Suite` es público.** Está verificado: se puede descargar `raw.githubusercontent.com/CHKI541/Lock-Suite/main/admin-backend/public/version.json` sin credenciales. Tiene que serlo, porque la actualización OTA baja el APK de ahí.

Eso significa que el código fuente completo de la app, las reglas de Firebase y la clave HMAC de los perfiles son legibles por cualquiera. Quien quiera evadir el bloqueo no necesita decompilar nada.

**Recomendación:** pasar el repositorio a privado y mover el APK y el `version.json` a Firebase Hosting, que ya está en uso y sirve archivos públicos sin publicar el código. Es el cambio de mayor impacto y menor esfuerzo de toda la lista.

Si se decide mantenerlo público, entonces hay que asumirlo en el diseño: ningún secreto en el código, y toda la seguridad apoyada en credenciales por dispositivo (lo que hace que 2.2 y 2.4 pasen de "conveniente" a "necesario").

---

## 4. Nota sobre método

Todos los problemas de esta lista **compilan perfectamente**. `BUILD SUCCESSFUL` y `node --check` cubren errores de sintaxis, no de comportamiento: las reglas de Firebase que no protegen lo que dicen proteger, el UID del sistema tratado como si fuera de una app, o una restricción que se saltea y devuelve éxito, todos pasan la compilación sin una advertencia.

Al terminar cada tarea, conviene dejar registrado no solo *qué* se cambió sino *cómo se verificó que el cambio hace lo que dice* — idealmente con una prueba en un equipo real, y si no es posible, diciendo explícitamente que no se probó.

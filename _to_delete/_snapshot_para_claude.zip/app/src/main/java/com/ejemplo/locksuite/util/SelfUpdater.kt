package com.ejemplo.locksuite.util

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object SelfUpdater {
    private const val VERSION_URL = "https://locksuite-nueva.web.app/version.json"
    private const val FALLBACK_VERSION_URL = "https://locksuite-nueva.firebaseapp.com/version.json"

    suspend fun checkAndPerformUpdate(context: Context, showToasts: Boolean = false, onProgress: ((Int) -> Unit)? = null): String? {
        return withContext(Dispatchers.IO) {
            var temporaryInstallAccessPrepared = false
            var installCommitSubmitted = false
            try {
                if (showToasts) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Buscando actualizaciones de LockSuite...", Toast.LENGTH_SHORT).show()
                    }
                }

                val responseText = fetchVersionManifest()
                val json = JSONObject(responseText)
                val serverVersionCode = json.optInt("versionCode", 0)
                val apkUrl = json.optString("url", "")

                val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                val currentVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pInfo.longVersionCode.toInt()
                } else {
                    @Suppress("DEPRECATION")
                    pInfo.versionCode
                }

                if (serverVersionCode <= currentVersionCode) {
                    if (showToasts) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "LockSuite ya está actualizado (v${pInfo.versionName})", Toast.LENGTH_SHORT).show()
                        }
                    }
                    return@withContext null
                }

                if (showToasts) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Descargando actualización de LockSuite...", Toast.LENGTH_SHORT).show()
                    }
                }

                val tempFile = File(context.cacheDir, "locksuite_update.apk")
                val apkConnection = URL(apkUrl).openConnection() as HttpURLConnection
                apkConnection.connectTimeout = 15000
                apkConnection.readTimeout = 15000
                apkConnection.connect()

                if (apkConnection.responseCode != HttpURLConnection.HTTP_OK) {
                    return@withContext "Error al descargar APK: HTTP ${apkConnection.responseCode}"
                }

                val totalBytes = apkConnection.contentLength
                var bytesDownloaded = 0
                apkConnection.inputStream.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(16384)
                        var bytesRead: Int
                        var lastReportedProgress = -1
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            bytesDownloaded += bytesRead
                            if (totalBytes > 0) {
                                val progress = (bytesDownloaded * 100L / totalBytes).toInt()
                                if (progress != lastReportedProgress) {
                                    lastReportedProgress = progress
                                    onProgress?.invoke(progress)
                                }
                            }
                        }
                    }
                }

                if (showToasts) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Instalando actualización de LockSuite...", Toast.LENGTH_SHORT).show()
                    }
                }

                // Levantar restricciones ANTES de crear la sesión (Android valida al crear, no al commit)
                if (!prepareTemporaryInstallAccess(context)) {
                    return@withContext "No se pudieron preparar los permisos temporales de instalación."
                }
                temporaryInstallAccessPrepared = true

                val pm = context.packageManager
                val packageInstaller = pm.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                params.setAppPackageName(context.packageName)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
                }

                val sessionId = packageInstaller.createSession(params)
                val session = packageInstaller.openSession(sessionId)
                // session.close() en finally: antes, si la copia fallaba a mitad de
                // camino, "fis"/"out"/la sesión de PackageInstaller quedaban sin
                // cerrar (saltaba directo al catch de abajo), acumulando sesiones
                // colgadas ante fallos repetidos de auto-actualización.
                try {
                    session.openWrite("COSU", 0, -1).use { out ->
                        FileInputStream(tempFile).use { fis ->
                            val buffer = ByteArray(65536)
                            var bytesRead: Int
                            while (fis.read(buffer).also { bytesRead = it } != -1) {
                                out.write(buffer, 0, bytesRead)
                            }
                            session.fsync(out)
                        }
                    }

                    val intent = Intent(context, com.ejemplo.locksuite.receiver.PackageInstallStatusReceiver::class.java)
                    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                    } else {
                        PendingIntent.FLAG_UPDATE_CURRENT
                    }
                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        sessionId,
                        intent,
                        flags
                    )

                    session.commit(pendingIntent.intentSender)
                    installCommitSubmitted = true
                } finally {
                    session.close()
                }

                tempFile.delete()
                return@withContext null
            } catch (e: Exception) {
                if (temporaryInstallAccessPrepared && !installCommitSubmitted) {
                    com.ejemplo.locksuite.mdm.PolicyManager(context).restoreInstallRestrictions()
                }
                Log.e("SelfUpdater", "Error de actualización", e)
                return@withContext "Error de actualización: ${e.message}"
            }
        }
    }

    suspend fun downloadAndInstallApk(context: Context, apkUrl: String, packageName: String, label: String, onProgress: ((Int) -> Unit)? = null): String? {
        return withContext(Dispatchers.IO) {
            var temporaryInstallAccessPrepared = false
            var installCommitSubmitted = false
            try {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Iniciando descarga de $label...", Toast.LENGTH_SHORT).show()
                }

                val tempFile = File(context.cacheDir, "store_${packageName}_update.apk")
                val apkConnection = URL(apkUrl).openConnection() as HttpURLConnection
                apkConnection.connectTimeout = 15000
                apkConnection.readTimeout = 15000
                apkConnection.connect()

                if (apkConnection.responseCode != HttpURLConnection.HTTP_OK) {
                    return@withContext "Error al descargar APK: HTTP ${apkConnection.responseCode}"
                }

                val totalBytes = apkConnection.contentLength
                var bytesDownloaded = 0
                apkConnection.inputStream.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(16384)
                        var bytesRead: Int
                        var lastReportedProgress = -1
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            bytesDownloaded += bytesRead
                            if (totalBytes > 0) {
                                val progress = (bytesDownloaded * 100L / totalBytes).toInt()
                                if (progress != lastReportedProgress) {
                                    lastReportedProgress = progress
                                    onProgress?.invoke(progress)
                                }
                            }
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Instalando $label en segundo plano...", Toast.LENGTH_SHORT).show()
                }

                // Levantar restricciones ANTES de crear la sesión (Android valida al crear, no al commit)
                if (!prepareTemporaryInstallAccess(context)) {
                    return@withContext "No se pudieron preparar los permisos temporales de instalación."
                }
                temporaryInstallAccessPrepared = true

                val pm = context.packageManager
                val packageInstaller = pm.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                params.setAppPackageName(packageName)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
                }

                val sessionId = packageInstaller.createSession(params)
                val session = packageInstaller.openSession(sessionId)
                // Mismo problema que en checkAndPerformUpdate: session.close() se
                // mueve a un finally para que "fis"/"out"/la sesión siempre se
                // cierren, incluso si la copia falla a mitad de camino.
                try {
                    session.openWrite("COSU", 0, -1).use { out ->
                        FileInputStream(tempFile).use { fis ->
                            val buffer = ByteArray(65536)
                            var bytesRead: Int
                            while (fis.read(buffer).also { bytesRead = it } != -1) {
                                out.write(buffer, 0, bytesRead)
                            }
                            session.fsync(out)
                        }
                    }

                    val intent = Intent(context, com.ejemplo.locksuite.receiver.PackageInstallStatusReceiver::class.java)
                    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                    } else {
                        PendingIntent.FLAG_UPDATE_CURRENT
                    }
                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        sessionId,
                        intent,
                        flags
                    )

                    session.commit(pendingIntent.intentSender)
                    installCommitSubmitted = true
                } finally {
                    session.close()
                }

                tempFile.delete()
                return@withContext null
            } catch (e: Exception) {
                if (temporaryInstallAccessPrepared && !installCommitSubmitted) {
                    com.ejemplo.locksuite.mdm.PolicyManager(context).restoreInstallRestrictions()
                }
                Log.e("SelfUpdater", "Error al instalar $label", e)
                return@withContext "Error al instalar $label: ${e.message}"
            }
        }
    }

    private fun prepareTemporaryInstallAccess(context: Context): Boolean {
        try {
            PrefsHelper.getMdmPrefs(context)
                .edit()
                .putBoolean("mdm_install_in_progress", true)
                .apply()

            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? android.app.admin.DevicePolicyManager
                ?: throw IllegalStateException("DevicePolicyManager no disponible")
            val adminComponent = android.content.ComponentName(context, com.ejemplo.locksuite.receiver.DeviceAdminReceiver::class.java)
            if (!dpm.isDeviceOwnerApp(context.packageName)) {
                throw IllegalStateException("LockSuite no es el propietario del dispositivo")
            }

            // Programar el cierre de seguridad antes de abrir la ventana de
            // instalación. Si no puede programarse, las políticas no se relajan.
            if (!scheduleInstallSafetyTimeout(context)) {
                throw IllegalStateException("No se pudo programar el cierre de seguridad de instalación")
            }

            dpm.clearUserRestriction(adminComponent, android.os.UserManager.DISALLOW_INSTALL_APPS)
            dpm.clearUserRestriction(adminComponent, android.os.UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)

            // Esperar a que Android propague el cambio de política antes de createSession()
            Thread.sleep(500)
            return true
        } catch (e: Exception) {
            Log.w("SelfUpdater", "Error al preparar permisos temporales de instalación: ${e.message}")
            com.ejemplo.locksuite.mdm.PolicyManager(context).restoreInstallRestrictions()
            return false
        }
    }

    private fun scheduleInstallSafetyTimeout(context: Context): Boolean {
        try {
            val intent = Intent(context, com.ejemplo.locksuite.receiver.PackageReceiver::class.java).apply {
                action = "INSTALL_SAFETY_TIMEOUT"
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = PendingIntent.getBroadcast(context, 9922, intent, flags)
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val triggerAtMs = android.os.SystemClock.elapsedRealtime() + 120_000
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtMs, pendingIntent)
            } else {
                alarmManager.set(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtMs, pendingIntent)
            }
            return true
        } catch (e: Exception) {
            Log.w("SelfUpdater", "Error al programar timeout de instalación: ${e.message}")
            return false
        }
    }

    private fun fetchVersionManifest(): String {
        var lastFailure: Exception? = null
        for (manifestUrl in listOf(VERSION_URL, FALLBACK_VERSION_URL)) {
            try {
                val urlWithCacheBuster = "$manifestUrl?t=${System.currentTimeMillis()}"
                val connection = URL(urlWithCacheBuster).openConnection() as HttpURLConnection
                connection.connectTimeout = 10_000
                connection.readTimeout = 10_000
                connection.instanceFollowRedirects = false
                try {
                    if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                        throw IOException("HTTP ${connection.responseCode} al consultar $manifestUrl")
                    }
                    return connection.inputStream.bufferedReader().use { reader -> reader.readText() }
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                lastFailure = e
                Log.w("SelfUpdater", "No se pudo consultar manifiesto OTA: $manifestUrl", e)
            }
        }
        throw IOException("No se pudo consultar ningún manifiesto OTA", lastFailure)
    }
}
